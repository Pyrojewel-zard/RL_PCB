A library for representing PCB netlists. More documentation coming soon.
