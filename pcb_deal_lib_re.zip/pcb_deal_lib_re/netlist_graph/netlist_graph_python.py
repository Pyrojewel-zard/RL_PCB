#!/usr/bin/env python3
"""
Netlist Graph Python模块 - 基于pcb_python的netlist_graph重构
提供图形分析、节点管理、边连接等功能
"""

import sys
import os
from typing import List, Optional, Tuple, Set
from pathlib import Path

# 添加pcb_python路径
pcb_python_path = Path(__file__).parent.parent.parent / "pcb_python"
sys.path.insert(0, str(pcb_python_path))

from netlist_graph import Graph, Node, Edge, Board, Optimal, Utils

# 重新导出所有类，保持API兼容性
__all__ = ['Graph', 'Node', 'Edge', 'Board', 'Optimal', 'Utils']

def build_info() -> None:
    """打印库构建信息"""
    print("Netlist Graph Python Library v1.0.0")
    print("基于pcb_python的netlist_graph重构")
    print("支持图形分析、节点管理、边连接等功能")

def get_library_version() -> str:
    """返回库版本信息"""
    return "1.0.0" 