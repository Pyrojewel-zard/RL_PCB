import sys

try:
    import graph.graph as graph
except Exception as e: 
    print(e)
    sys.exit(-1)       

graph.build_info()
#placer.dependency_info()
