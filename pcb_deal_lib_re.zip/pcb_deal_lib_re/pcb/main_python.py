#!/usr/bin/env python3
"""
PCB Python主模块 - 基于pcb_python的重构版本
演示如何使用重构后的PCB和netlist_graph模块
"""

import sys
import os
from pathlib import Path

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 导入重构后的模块
from pcb_python import PCB, VPtrPCBs, read_pcb_file, build_info as pcb_build_info
from netlist_graph_python import Graph, Node, Edge, Board, build_info as graph_build_info

def main():
    """主函数 - 演示重构后的功能"""
    print("=== PCB Python重构版本演示 ===\n")
    
    # 打印构建信息
    pcb_build_info()
    print()
    graph_build_info()
    print()
    
    # 创建PCB对象
    p = PCB()
    
    # 示例：从单独文件创建PCB文件
    print("=== 从单独文件创建PCB文件 ===")
    nodes_file = "./test/kicad_parser/bistable_oscillator_with_555_timer_and_ldo.nodes"
    edges_file = "./test/kicad_parser/bistable_oscillator_with_555_timer_and_ldo.edges"
    board_file = "./test/kicad_parser/bistable_oscillator_with_555_timer_and_ldo.board"
    filename = "./test/kicad_parser/output/bistable_oscillator_with_555_timer_and_ldo"
    
    # 检查文件是否存在
    if os.path.exists(nodes_file) and os.path.exists(edges_file) and os.path.exists(board_file):
        result = p.write_pcb_file_from_individual_files(filename, nodes_file, edges_file, board_file, True)
        if result == 0:
            print(f"成功创建PCB文件: {filename}")
        else:
            print(f"创建PCB文件失败: {filename}")
    else:
        print("示例文件不存在，跳过文件创建测试")
    
    print()
    
    # 示例：读取PCB文件
    print("=== 读取PCB文件 ===")
    pcb_file = "./test/kicad_parser/bistable_oscillator_with_555_timer_and_ldo.pcb"
    if os.path.exists(pcb_file):
        result = p.read_pcb_file(pcb_file)
        if result == 0:
            print(f"成功读取PCB文件: {pcb_file}")
            p.print_statistics()
        else:
            print(f"读取PCB文件失败: {pcb_file}")
    else:
        print("示例PCB文件不存在，跳过文件读取测试")
    
    print()
    
    # 示例：使用VPtrPCBs
    print("=== 使用VPtrPCBs ===")
    pv = VPtrPCBs()
    if os.path.exists(pcb_file):
        result = read_pcb_file(pcb_file, pv)
        if result == 0 and len(pv) > 0:
            pcb = pv[0]
            print(f"成功加载PCB: {pcb}")
            pcb.print_statistics()
        else:
            print("加载PCB失败")
    else:
        print("示例PCB文件不存在，跳过VPtrPCBs测试")
    
    print()
    
    # 示例：图形分析
    print("=== 图形分析示例 ===")
    if len(pv) > 0:
        pcb = pv[0]
        g = Graph()
        b = Board()
        pcb.get_graph(g)
        pcb.get_board(b)
        
        print(f"图形统计:")
        g.statistics()
        
        print(f"电路板信息:")
        b.print()
        
        print(f"节点连接性分析:")
        connectivity = g.get_nodes_connectivity_list()
        print(f"  按连接数排序的节点: {connectivity[:5]}...")  # 显示前5个
        
        print(f"HPWL计算:")
        hpwl = g.calc_hpwl()
        print(f"  半周长线长: {hpwl:.2f}")
    
    print("\n=== 演示完成 ===")

if __name__ == "__main__":
    main() 