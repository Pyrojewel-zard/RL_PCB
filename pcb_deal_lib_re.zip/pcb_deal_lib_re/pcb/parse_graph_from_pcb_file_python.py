#!/usr/bin/env python3
"""
PCB图形解析器 - Python版本
基于pcb_python的netlist_graph重构
"""

import sys
import os
from pathlib import Path

# 添加pcb_python路径
pcb_python_path = Path(__file__).parent.parent.parent / "pcb_python"
sys.path.insert(0, str(pcb_python_path))

from netlist_graph import Graph, Node, Edge, Board
from pcb_python import PCB, VPtrPCBs, read_pcb_file

def parse_pcb_file(pcb_file_path: str):
    """解析PCB文件并提取图形信息"""
    print(f"解析PCB文件: {pcb_file_path}")
    
    # 创建PCB对象
    p = PCB()
    g = Graph()
    b = Board()
    
    # 创建PCB指针向量
    pv = VPtrPCBs()
    
    # 读取PCB文件
    result = read_pcb_file(pcb_file_path, pv)
    if result != 0 or len(pv) == 0:
        print("读取PCB文件失败")
        return None, None, None
    
    # 获取第一个PCB
    p = pv[0]
    p.get_graph(g)
    p.get_board(b)
    
    # 设置组件原点为零
    g.set_component_origin_to_zero(b)
    
    print("")
    nv = g.get_nodes()
    ev = g.get_edges()
    
    V = []
    E = []
    duplicate = 0
    
    # 处理节点
    print("=== 节点信息 ===")
    for n in nv:
        v = []
        
        size = n.get_size()
        v.append(float(size[0]))
        v.append(float(size[1]))
        
        pos = n.get_pos()
        v.append(float(pos[0]))
        v.append(float(pos[1]))
        
        v.append(float(n.get_orientation()))
        v.append(float(n.get_pin_count()))
        
        print(v)
        V.append(v)
    
    print('')
    
    # 处理边
    print("=== 边信息 ===")
    for edge in ev:
        e = []
        duplicate_found = False
        
        # 跳过GND边
        if edge.get_power_rail() == 1:
            continue
        
        e.append(int(edge.get_instance_id(0)))
        e.append(int(edge.get_instance_id(1)))
        print(e)
        
        # 检查重复边
        for e2 in E:
            if ((e[0] == e2[0] and e[1] == e2[1]) or 
                (e[0] == e2[1] and e[1] == e2[0])):
                duplicate += 1
                duplicate_found = True
                break
        
        if not duplicate_found:
            E.append(e)
    
    print(f'图形中的顶点数量: {len(V)}')
    print(f'图形中的边数量: {len(E)} (排除 {duplicate} 个重复边)')
    
    return V, E, g

def main():
    """主函数"""
    # 示例PCB文件路径
    pcb_file = './test/102000303_0.56_BananaSchplit_w_connectors_and_mounting_holes_2lyr.pcb'
    
    if os.path.exists(pcb_file):
        V, E, graph = parse_pcb_file(pcb_file)
        if V is not None and E is not None:
            print("\n=== 解析完成 ===")
            print(f"成功解析 {len(V)} 个节点和 {len(E)} 条边")
            
            # 打印图形统计信息
            print("\n=== 图形统计 ===")
            graph.statistics()
            
            # 计算HPWL
            hpwl = graph.calc_hpwl()
            print(f"HPWL: {hpwl:.2f}")
        else:
            print("解析失败")
    else:
        print(f"PCB文件不存在: {pcb_file}")
        print("请确保文件路径正确")

if __name__ == "__main__":
    main() 